export const JOB_STATUSES = [
  "PENDING",
  "IN_PROGRESS",
  "COMPLETED",
  "CANCELLED"
] as const;

export type JobStatus = typeof JOB_STATUSES[number];

export function isValidJobTransition(
    currentStatus: JobStatus,
    newStatus: JobStatus
): boolean {
    if (currentStatus === "PENDING") {
        return newStatus === "IN_PROGRESS";
    }

    if (currentStatus === "IN_PROGRESS") {
        return newStatus === "COMPLETED" || newStatus === "CANCELLED";
    }

    return false;
}